package com.mycompany.wheen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
