import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDNeITdUX8RunIv7a_qxHkdqXcRJxX5E8Q",
            authDomain: "wheen-g4ewtt.firebaseapp.com",
            projectId: "wheen-g4ewtt",
            storageBucket: "wheen-g4ewtt.appspot.com",
            messagingSenderId: "143721554441",
            appId: "1:143721554441:web:27f1827cec1e5bf1130ed8"));
  } else {
    await Firebase.initializeApp();
  }
}
